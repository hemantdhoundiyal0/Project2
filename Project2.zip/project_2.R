# cleaning the environment
rm(list = ls())

#setting the working directory and then checking, is it properly set or not
setwd("C:\\Users\\admin\\Downloads")
getwd()

#importing required libraries
library(ggplot2) #for visuvalisations
install.packages("corrgram")
library(corrgram)
install.packages("usdm")
library(usdm)
install.packages("rpart")
library(rpart)
install.packages("DMwR")
library(DMwR)
install.packages("lubridate")
library(lubridate)
install.packages("anytime")
library(anytime)
library(dplyr)

#getting the data from directory
df=read.csv("train_cab.csv")
df_test=read.csv("test.csv")

#take a look of the data
View(df)
View(df_test)
#lets see the number of observations the data have
dim(df)

#lets see the structure of the data have
str(df)

# lets see all the columns name
colnames(df)

# lets see the last few rows of the data
tail(df,10)

#lets see the unique values of pickup_datetime
unique(df$pickup_datetime)

#lets see the unique passenger_count
unique(df$passenger_count)

#count of unique values in the passenger count
length(unique(df$passenger_count))

#lets see how many times each unique value appears in the dataset
table(df$passenger_count)

#checking the unique values and its count for the fare_amount variable
table(df$fare_amount)

#summary of a variable
summary(df)

#chaning the blank spaces into na
df$fare_amount[df$fare_amount==""] <- "NA"

#converting the data type from factor to character
df$fare_amount=as.character(df$fare_amount)

#converting the data type of fare_amount to numeric from character
df$fare_amount=as.numeric(df$fare_amount) 

#### Now some pre-processing ####

### MISSING VALUES ###
#creating dataframe with missing % 
mis_val=data.frame(apply(df,2,function(x){sum(is.na(x))}))
mis_val

#let us check, 1001th value of pickup_latitude
df[1001,4] # actual value=40.75966

#placing NA at 1001th place in pickup_latitude variable
df[1001,4]=NA

# check the mean in this variable
df$pickup_latitude[is.na(df$pickup_latitude)]=mean(df$pickup_latitude,na.rm=T)
df[1001,4]  # mean value=39.91467

#placing NA at 1001th place in pickup_latitude variable
df[1001,4]=NA #again creatng the missing values

# now trying the median method
df$pickup_latitude[is.na(df$pickup_latitude)]=median(df$pickup_latitude,na.rm=T)
df[1001,4]  # median value=40.7526


#now putting the original value at 100th place in latitude variable
df[1001,4]=40.75966

df= knnImputation(df,k=5)
df[1001,4] #knn value = 40.74527

#using median method to fill all the NA values
df$fare_amount[is.na(df$fare_amount)]=median(df$fare_amount,na.rm=T)
df$passenger_count[is.na(df$passenger_count)]=median(df$passenger_count,na.rm=T)

#imputing the missing values using median method
mis_val=data.frame(apply(df,2,function(x){sum(is.na(x))}))
mis_val

#lets again check the summary
summary(df)

#changing the datatype of pickup_datetime variable to POSIXct(used for datetime) from factor
df$pickup_datetime=as.character(df$pickup_datetime) # here from factor to character
df$pickup_datetime=as_datetime(df$pickup_datetime) #here from character to POSIXct

#changing the datatype of pickup_datetime in test data
df_test$pickup_datetime=as.character(df_test$pickup_datetime) # here from factor to character
df_test$pickup_datetime=as_datetime(df_test$pickup_datetime) #here from character to POSIXct


# now checking the structure of the data once
str(df)

#extracting some columns from pickup_datetime
df$pickup_datetime=as.character(df$pickup_datetime)
df$Month=month(df$pickup_datetime)
df$Day=day(df$pickup_datetime)
df$Hour=hour(df$pickup_datetime)



#filling up the missing values in these features
df$Month[is.na(df$Month)]=median(df$Month,na.rm=T)
df$Day[is.na(df$Day)]=median(df$Day,na.rm=T)
df$Hour[is.na(df$Hour)]=median(df$Hour,na.rm=T)
#droping the pickup_datetime column
df=select(df,-pickup_datetime)


#extracting some columns in test data
df_test$pickup_datetime=as.character(df_test$pickup_datetime)
df_test$Month=month(df_test$pickup_datetime)
df_test$Hour=hour(df_test$pickup_datetime)

#droping the pickup_datetime column
df_test=select(df_test,-pickup_datetime)


### OUTLIERS DETECTION AND REMOVAL ###

boxplot(df$fare_amount,
        main = "Boxplots",
        xlab = "fare_amount",
        ylab = "count",
        col = "orange",
        border = "brown"
)

boxplot(df$pickup_longitude,
        main = "Boxplots",
        xlab = "pickup_longitude",
        ylab = "count",
        col = "orange",
        border = "brown"
)
boxplot(df$pickup_latitude,
        main = "Boxplots",
        xlab = "pickup_latitude",
        ylab = "count",
        col = "orange",
        border = "brown"
)
boxplot(df$dropoff_longitude,
        main = "Boxplots",
        xlab = "dropoff_longitude",
        ylab = "count",
        col = "orange",
        border = "brown"
)
boxplot(df$dropoff_latitude,
        main = "Boxplots",
        xlab = "dropoff_latitude",
        ylab = "count",
        col = "orange",
        border = "brown"
)
boxplot(df$passenger_count,
        main = "Boxplots",
        xlab = "passenger_count",
        ylab = "count",
        col = "orange",
        border = "brown"
)
cnames=c("pickup_longitude","pickup_latitude","dropoff_longitude","dropoff_latitude")
for(i in cnames){
        val=df[,i][df[,i]%in%boxplot.stats(df[,i])$out]
        df[,i][df[,i]%in%val]=NA
}

# removing the extreme values from fare_amount and passenger_count        
df$fare_amount[df$fare_amount>50|df$fare_amount<0  ] = NA
df$passenger_count[df$passenger_count>6|df$passenger_count<0  ] = NA

# checking the missing values
mis_val=data.frame(apply(df,2,function(x){sum(is.na(x))}))
mis_val

#now filling up the removed values
df$fare_amount[is.na(df$fare_amount)]=median(df$fare_amount,na.rm=T)
df$pickup_longitude[is.na(df$pickup_longitude)]=median(df$pickup_longitude,na.rm=T)
df$pickup_latitude[is.na(df$pickup_latitude)]=median(df$pickup_latitude,na.rm=T)
df$dropoff_longitude[is.na(df$dropoff_longitude)]=median(df$dropoff_longitude,na.rm=T)
df$dropoff_latitude[is.na(df$dropoff_latitude)]=median(df$dropoff_latitude,na.rm=T)
df$passenger_count[is.na(df$passenger_count)]=median(df$passenger_count,na.rm=T)


## Feature Selection & Feature Scaling ##
#checking whether data is normally distributed or not
qqnorm(df$fare_amount)

hist(df$fare_amount)

#taking the log of the month and day features
df$Month=log10(df$Month)
df$Day=log10(df$Day)
hist(df$Month)
hist(df$Day)

#taking log of month and day variable in test data
df_test$Month=log10(df_test$Month)


# doing min-max normaliasation
cl_nam=c("pickup_longitude","pickup_latitude","dropoff_longitude","dropoff_latitude","Hour")


for (i in cl_nam) {
        print(i)
        df[,i]=((df[,i]-min(df[,i]))/(max(df[,i])-min(df[,i])))
}

#min-max normalasition in test data set
cl_nam_test=c("pickup_longitude","pickup_latitude","dropoff_longitude","dropoff_latitude","Hour")
#converting int to numeric(feature hour)
df_test$Hour=as.numeric(df_test$Hour)

for (i in cl_nam_test) {
        print(i)
        df_test[,i]=((df_test[,i]-min(df_test[,i]))/(max(df_test[,i])-min(df_test[,i])))
}
str(df_test)

##now selecting the important features from the dataset using correlation plot
corrgram((df[,]),order = F,
         upper.panel = panel.cor, text.panel = panel.txt,main="Correlation Plot")


#Removing one of the variable from two highly correlated independent variables 
#and very less correlated dependent and independent variables
df = subset(df, select = -c(dropoff_latitude,pickup_latitude,Day))
View(df)  

df_test=subset(df_test,select=-c(dropoff_latitude,pickup_latitude))
#### MODELING ####
#### Linear Regression ####

train_index = sample(1:nrow(df),0.8*nrow(df))
train = df[train_index,]
test = df[-train_index,]


# checking collinearity problem
vif(df[,-1])
vifcor(df[,-1],th=0.5)

#developing the model on the train dataset
lm_model = lm(fare_amount~., data = train)

#summary of the model
summary(lm_model)


####predicting the values of test case ###
prediction_lm = predict(lm_model,test[,2:6])
prediction_test=predict(lm_model,df_test[,1:5])
##predicted values for fare_amount in test data by Linear Regression
prediction_test

#checking for the error rate (predicted VS original)
rmse=sqrt(mean((test[,1]-prediction_lm)^2))
rmse

### Decision Tree Regression ###
fit= rpart(fare_amount~.,data=train)

#predicting new values
prediction=predict(fit,test[,-1])


######predicted values for fare amount in test data by decision tree ###
prediction_test_Decesion=predict(fit,df_test)
prediction_test_Decesion

#error in decision tree
rms=sqrt(mean(test[,1]-prediction)^2)
rms
View(df_test)
